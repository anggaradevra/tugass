package com.example.pmb;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface API {
    @FormUrlEncoded
    @POST("signin.php")
    Call<respon> signin (@Field("email") String email,
                         @Field("password") String password);

    @FormUrlEncoded
    @POST("simpan.php")
    Call<respon> simpan(@Field("email") String email,
                        @Field("password") String password,
                        @Field("nama") String nama,
                        @Field("tanggal_lahir") String tanggal_lahir,
                        @Field("jenis_kelamin") String jenis_kelamin,
                        @Field("alamat") String alamat,
                         @Field("asal_sekolah") String asal_sekolah,
                         @Field("nomor") String nomor);
}
