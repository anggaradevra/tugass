package com.example.pmb;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class home extends AppCompatActivity implements View.OnClickListener {
    TextView biodata, jurusan, maba, signOut, txtUser;
    private List<tampil> results = new ArrayList<>();
    private Intent Intent;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        biodata = (TextView) findViewById(R.id.tv_biodata);
        jurusan = (TextView) findViewById(R.id.tv_jurusan);
        maba = (TextView) findViewById(R.id.tv_listmaba);

        biodata.setOnClickListener(this);
        jurusan.setOnClickListener(this);
        maba.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.tv_biodata:
                Intent b = new Intent(home.this, biodata.class);
                startActivity(b);
                break;

            case R.id.tv_jurusan:
                Intent j = new Intent(home.this, jurusan.class);
                startActivity(j);
                break;

            case R.id.tv_listmaba:
                Intent d = new Intent(home.this, list_maba.class);
                startActivity(d);
                break;
        }
    }
}
