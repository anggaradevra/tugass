package com.example.pmb;

public class tampil {
    String id_mahasiswa, nama, tanggal_lahir, alamat, agama, nomor, email;

    public String getId_mahasiswa() {
        return id_mahasiswa;
    }

    public String getNama() {
        return nama;
    }

    public String getTanggal_lahir() {
        return tanggal_lahir;
    }

    public String getAlamat() {
        return alamat;
    }

    public String getAgama() {
        return agama;
    }

    public String getNomor() {
        return nomor;
    }

    public String getEmail() {
        return email;
    }
}
