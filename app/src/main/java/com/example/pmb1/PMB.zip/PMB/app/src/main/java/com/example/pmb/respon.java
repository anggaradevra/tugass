package com.example.pmb;

public class respon {
    String value, message;

    public String getValue(){
        return value;
    }

    public String getMessage(){
        return message;
    }
}
