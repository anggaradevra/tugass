package com.example.pmb1;

public class tampil {
    String id_mahasiswa, nama, tanggal_lahir, jenis_kelamin, alamat, agama, asal_sekolah, nomor, email;

    public String getId_mahasiswa() {
        return id_mahasiswa;
    }

    public String getNama() {
        return nama;
    }

    public String getTanggal_lahir() {
        return tanggal_lahir;
    }

    public String getJenis_kelamin() {
        return jenis_kelamin;
    }

    public String getAlamat() {
        return alamat;
    }

    public String getAgama() {
        return agama;
    }

    public String getAsal_sekolah() {
        return asal_sekolah;
    }

    public String getNomor() {
        return nomor;
    }

    public String getEmail() {
        return email;
    }
}
