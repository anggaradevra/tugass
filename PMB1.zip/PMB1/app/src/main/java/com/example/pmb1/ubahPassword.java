package com.example.pmb1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ubahPassword extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubah_password);
    }
}